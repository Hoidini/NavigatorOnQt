-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: navigator
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `houses`
--

DROP TABLE IF EXISTS `houses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `houses` (
  `house_id` smallint unsigned NOT NULL AUTO_INCREMENT,
  `country` varchar(20) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `street` varchar(20) DEFAULT NULL,
  `home_number` smallint unsigned DEFAULT NULL,
  `part_of_home_number` smallint unsigned DEFAULT NULL,
  `coordinate_x` float DEFAULT NULL,
  `coordinate_y` float DEFAULT NULL,
  `size_x` float DEFAULT NULL,
  `size_y` float DEFAULT NULL,
  PRIMARY KEY (`house_id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `houses`
--

LOCK TABLES `houses` WRITE;
/*!40000 ALTER TABLE `houses` DISABLE KEYS */;
INSERT INTO `houses` VALUES (2,'Russia','Kazan','Universiate Village',1,1,29.26,2.08,0.66,4.81),(3,'Russia','Kazan','Universiate Village',1,2,29.92,2.08,4.71,0.72),(4,'Russia','Kazan','Universiate Village',1,3,33.8,2.94,0.86,3.5),(5,'Russia','Kazan','Universiate Village',2,1,24.3,1.94,3.51,0.83),(6,'Russia','Kazan','Universiate Village',2,2,23.75,2.56,0.85,3.78),(7,'Russia','Kazan','Universiate Village',3,1,16.27,1.84,0.73,2.77),(8,'Russia','Kazan','Universiate Village',3,2,17,1.84,4.5,0.86),(9,'Russia','Kazan','Universiate Village',3,3,20.78,2.7,0.62,1.34),(10,'Russia','Kazan','Universiate Village',4,1,9.97,1.66,4,1.04),(11,'Russia','Kazan','Universiate Village',4,2,13.17,2.67,0.75,4.36),(12,'Russia','Kazan','Universiate Village',5,1,3.08,1.56,0.73,4.36),(13,'Russia','Kazan','Universiate Village',5,2,3.84,1.56,4.46,0.77),(14,'Russia','Kazan','Universiate Village',5,3,7.55,2.36,0.83,1.28),(15,'Russia','Kazan','Universiate Village',6,1,39.37,8.04,1,2.3),(16,'Russia','Kazan','Universiate Village',6,2,38.77,10.23,1,2.3),(17,'Russia','Kazan','Universiate Village',7,1,37.15,8.04,1,2.3),(18,'Russia','Kazan','Universiate Village',7,2,36.44,10.05,1,2.3),(19,'Russia','Kazan','Universiate Village',8,1,34.85,8.01,1,2.3),(20,'Russia','Kazan','Universiate Village',8,2,34.18,10.23,1,2.3),(21,'Russia','Kazan','Universiate Village',9,1,32.56,8,1,2.3),(22,'Russia','Kazan','Universiate Village',9,2,31.89,10.23,1,2.3),(23,'Russia','Kazan','Universiate Village',10,1,30.23,8.01,1,2.3),(24,'Russia','Kazan','Universiate Village',10,2,29.6,10.23,1,2.3),(25,'Russia','Kazan','Universiate Village',10,3,28.75,8.11,1,1.2),(26,'Russia','Kazan','Universiate Village',11,3,27,11,1,1),(27,'Russia','Kazan','Universiate Village',11,1,25.75,7.9,1,2.3),(28,'Russia','Kazan','Universiate Village',11,2,25.08,10.2,1,2.3),(29,'Russia','Kazan','Universiate Village',12,1,23.48,7.87,1,2.3),(30,'Russia','Kazan','Universiate Village',12,2,22.72,10.05,1,2.3),(31,'Russia','Kazan','Universiate Village',13,1,21.17,7.83,1,2.3),(32,'Russia','Kazan','Universiate Village',13,2,20.5,10.12,1,2.3),(33,'Russia','Kazan','Universiate Village',14,1,18.8,7.83,1,2.3),(34,'Russia','Kazan','Universiate Village',14,2,18.2,9.95,1,2.3),(35,'Russia','Kazan','Universiate Village',15,1,16.51,7.76,1,2.3),(36,'Russia','Kazan','Universiate Village',15,2,15.88,10.1,1,2.3),(37,'Russia','Kazan','Universiate Village',15,3,14.82,7.94,1,1.2),(38,'Russia','Kazan','Universiate Village',16,1,12.07,7.73,1,2.3),(39,'Russia','Kazan','Universiate Village',16,2,11.32,9.74,1,2.3),(40,'Russia','Kazan','Universiate Village',17,1,9.63,7.69,1,2.4),(41,'Russia','Kazan','Universiate Village',17,2,9,10,1,2.3),(42,'Russia','Kazan','Universiate Village',18,1,7.48,7.62,1,2.3),(43,'Russia','Kazan','Universiate Village',18,2,6.77,9.7,1,2.3),(44,'Russia','Kazan','Universiate Village',19,1,5.19,7.58,1,2.3),(45,'Russia','Kazan','Universiate Village',19,2,4.62,9.61,1,2.3),(46,'Russia','Kazan','Universiate Village',20,1,2.89,7.66,1,2.3),(47,'Russia','Kazan','Universiate Village',20,2,2.26,9.67,1,2.3),(48,'Russia','Kazan','Universiate Village',21,1,33.73,18.52,0.91,2.5),(49,'Russia','Kazan','Universiate Village',21,2,33,21,1,2.6),(50,'Russia','Kazan','Universiate Village',21,3,31.68,23.74,1.7,1.36),(51,'Russia','Kazan','Universiate Village',22,1,30.27,18.41,1.73,1.36),(52,'Russia','Kazan','Universiate Village',22,2,29.53,19.72,1,2.74),(53,'Russia','Kazan','Universiate Village',22,3,28.96,22.4,1,2.65),(54,'Russia','Kazan','Universiate Village',23,1,26.42,18.31,1,2.55),(55,'Russia','Kazan','Universiate Village',23,2,25.68,20.85,1,2.65),(56,'Russia','Kazan','Universiate Village',23,3,24.3,23.5,1.74,1.34),(57,'Russia','Kazan','Universiate Village',24,1,23.11,18.34,1.74,1.34),(58,'Russia','Kazan','Universiate Village',24,2,22.33,19.5,1.1,2.83),(59,'Russia','Kazan','Universiate Village',24,3,21.7,22.26,0.95,2.6),(60,'Russia','Kazan','Universiate Village',27,1,12.14,18.1,0.9,2.2),(61,'Russia','Kazan','Universiate Village',27,2,11.4,20.92,1,2.57),(62,'Russia','Kazan','Universiate Village',27,3,9.91,23.35,1.9,1.45),(63,'Russia','Kazan','Universiate Village',28,1,8.71,18.06,1.8,1.38),(64,'Russia','Kazan','Universiate Village',28,2,8.08,19.37,1,2.9),(65,'Russia','Kazan','Universiate Village',28,3,7.48,22.12,0.8,2.6),(66,'Russia','Kazan','Universiate Village',29,1,5.12,18.1,0.89,2.6),(67,'Russia','Kazan','Universiate Village',29,2,4.3,20.74,1,2.7),(68,'Russia','Kazan','Universiate Village',29,3,2.93,23.46,1.7,1.07),(69,'Russia','Kazan','Universiate Village',30,1,1.7,18,1.7,1.3),(70,'Russia','Kazan','Universiate Village',30,2,0.95,19.3,1.05,2.7),(71,'Russia','Kazan','Universiate Village',30,3,0.25,21.94,1.05,2.7),(72,'Russia','Kazan','Universiate Village',32,1,36,18.5,4.43,4);
/*!40000 ALTER TABLE `houses` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-07-03 11:41:25
